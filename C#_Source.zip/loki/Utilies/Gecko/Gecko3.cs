namespace Loki.Gecko
{
	public class Gecko3
	{
		public int nextId
		{
			get;
			set;
		}

		public Gecko5[] logins
		{
			get;
			set;
		}

		public object[] disabledHosts
		{
			get;
			set;
		}

		public int version
		{
			get;
			set;
		}
	}
}
