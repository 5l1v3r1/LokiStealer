namespace Loki.Gecko
{
	public enum Gecko2
	{
		Sequence = 48,
		Integer = 2,
		BitString = 3,
		OctetString = 4,
		Null = 5,
		ObjectIdentifier = 6
	}
}
